


void ADC_init(void);



void ADC_Demarrer_conversion(unsigned char voie);
 


int ADC_Lire_resultat ();
