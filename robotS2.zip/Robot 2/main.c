#include <msp430.h>
#include "ADC.h"
#include "Afficheur.h"
#include "Action.h"
#define BUTTON BIT3

int appui = 0;
 int compteur = 0;
 int seconde = 0;
 unsigned int capteurDevant=0;
 unsigned int capteurDroite=0;
 unsigned int capteurGauche=0;

int main( void )
{
  // Stop watchdog timer to prevent time out reset
  WDTCTL = WDTPW + WDTHOLD;

  BCSCTL2 = CALBC1_1MHZ;
  DCOCTL = CALDCO_1MHZ;
  P1DIR &= ~(BIT0 ); //capteur de lumiere droit gauche

  P1DIR |= BUTTON;

  P2DIR |= (BIT2|BIT1|BIT5|BIT4);
  P2DIR &= ~(BIT0|BIT3);

  P2SEL |= (BIT2|BIT4|BIT0|BIT3);
  P2SEL2 &= ~(BIT2|BIT4|BIT0|BIT3);

  P2OUT|=BIT2; //on envoie une tension au moteur droite

  P2OUT|=BIT4; //on envoie une tension au moteur gauche

  P1IE|=BIT3;//on applique l'interruption sur le bouton P1.3

  P1IES|=BIT3;//front descendant de P1.3

  P1REN |= BIT3;

  P1IFG &= ~(BIT3);

  TA1CTL = 0|(TASSEL_2|ID_0);
  TA1CTL |= MC_1;
  TA1CCTL1 |= OUTMOD_7;
 	  TA1CCTL2 |= OUTMOD_7;
 	 TA1CCR0 = 500; // this value to change
 	 TA1CCR1 = 355;
 	TA1CCR2 = 350;
  P2OUT &= ~BIT5; //0
  P2OUT |= BIT1; //1

  /*
  TACTL = TASSEL_2 + ID_3 + MC_2; //p�riode de 1s

    TA0CCTL0 = CCIE; //interruption au bout de 60s

    TA0CCR0 = 62500; //TAOCCRO pour 1s
*/
  ADC_init();
  Aff_Init();

  while(1){

	    ADC_Demarrer_conversion(0); //on d�marre la conversion
	    capteurDevant=ADC_Lire_resultat(); //on lit le r�sultat
	    Aff_valeur(convert_Hex_Dec(capteurDevant));
	    /*ADC_Demarrer_conversion(0); //on d�marre la conversion
	    capteurDroite=ADC_Lire_resultat(); //on lit le r�sultat

	    Aff_valeur(convert_Hex_Dec(capteurDroite));*/
	    //capteurDroite = (capteurDroite -360)/6;

	   // ADC_Demarrer_conversion(7); //on d�marre la conversion
	    //capteurGauche=ADC_Lire_resultat(); //on lit le r�sultat
	  //  capteurGauche = (capteurGauche -360)/6;
	   /* ADC_Demarrer_conversion(5); //on d�marre la conversion
	    capteurligneGauche=ADC_Lire_resultat(); //on lit le r�sultat

	    ADC_Demarrer_conversion(4); //on d�marre la conversion
	    capteurligneDroite=ADC_Lire_resultat(); //on lit le r�sultat*/

	  if(capteurDevant<420){

		  	  	 Straight();
	      		//__delay_cycles(200000);
	      		//SpeedUp();

	      	}
	      	else{
	      		Stop();
	      		/*if(capteurDroite<600){
	      			TurnRight();
	      			Stop();
	      		}
	      		else{
	      			TurnLeft();
	      			Stop();
	      		}*/
	      	}

	 /* ADC_Demarrer_conversion(0x01);
	  mesure = ADC_Lire_resultat();
	  lumiere = (mesure -360)/6;
	  if (lumiere<20)

		   Aff_4carac("nuit");
	  else Aff_4carac("jour");

 	  for (i=0; i<40000; i++);*/
  }

}

#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void){

  if(appui){
    appui = 0;
    TA1CCTL1 = OUTMOD_0;      //moteurs �teints
    TA1CCTL2 = OUTMOD_0;
    TA1CCR1 = 0;
    TA1CCR2 = 0;
  }else{
	  appui = 1;

  }
P1IFG&=~BIT3;
}

#pragma vector=TIMER0_A0_VECTOR
__interrupt void ma_capture(void)

{

  if(seconde >= 62){ //condition pour le timer du temps
    TACTL = MC_0;
    TA1CCTL1 = OUTMOD_0;        //moteurs �teints
    TA1CCTL2 = OUTMOD_0;
  }else{
     seconde++; //on incr�mente
  }

  }
