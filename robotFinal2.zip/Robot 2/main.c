#include <msp430.h>
#include "ADC.h"
#include "Action.h"
#define BUTTON BIT3

int cercle = 0, start = 0;
unsigned int i;
int c[2];
int obstacle = 0;
int compare;
unsigned int capteurDevant = 0;
unsigned int capteurL[2];
unsigned int capteurBlancL, capteurBlancR;

int main(void)
{
    // Stop watchdog timer to prevent time out reset
    WDTCTL = WDTPW + WDTHOLD;
    BCSCTL2 = CALBC1_1MHZ;
    DCOCTL = CALDCO_1MHZ;
    P1SEL &= ~(BIT0 | BIT1 | BIT2 | BIT4 | BIT5);
    P1SEL2 &= ~(BIT0 | BIT1 | BIT2 | BIT4 | BIT5);
    P1DIR &= ~(BIT0 | BIT1 | BIT2 | BIT4 | BIT5); //capteur

    P2DIR |= (BIT2 | BIT1 | BIT5 | BIT4);
    P2DIR &= ~(BIT0 | BIT3);

    P2SEL |= (BIT2 | BIT4 | BIT0 | BIT3);
    P2SEL2 &= ~(BIT2 | BIT4 | BIT0 | BIT3);

    P2OUT |= (BIT2 | BIT4); //on envoie une tension au moteur droite

    TA1CTL = 0 | (TASSEL_2 | ID_0);
    TA1CTL |= MC_1;
    TA1CCTL1 |= OUTMOD_7;
    TA1CCTL2 |= OUTMOD_7;
    TA1CCR0 = 500; // this value to change
    TA1CCR1 = 355;
    TA1CCR2 = 350;
    P2OUT &= ~BIT5; //0
    P2OUT |= BIT1; //1

    ADC_init();

    while (1)
    {
        ADC_Demarrer_conversion(0); //on d�marre la conversion
        capteurDevant = ADC_Lire_resultat(); //on lit le r�sultat

        ADC_Demarrer_conversion(1); //on d�marre la conversion
        capteurL[0] = ADC_Lire_resultat() + 125; // droite

        ADC_Demarrer_conversion(2);
        capteurL[1] = ADC_Lire_resultat(); //gauche
        //Pour Noir ou BLanc
        ADC_Demarrer_conversion(5);
        capteurBlancL = ADC_Lire_resultat();
        ADC_Demarrer_conversion(4);
        capteurBlancR = ADC_Lire_resultat();

        if (capteurDevant < 400)
        {
            if(start == 0){
                Straight();
                start=1;
            }

            if (cercle == 0)
            {
                for (i = 0; i < 2; i++)
                {
                    if (capteurL[i] <= 340)
                    {
                        c[i] = 0;
                    }
                    else if (capteurL[i] <= 420)
                    {
                        c[i] = 1;
                    }
                    else if (capteurL[i] <= 500)
                    {
                        c[i] = 2;
                    }
                    else if (capteurL[i] <= 580)
                    {
                        c[i] = 3;
                    }
                    else if (capteurL[i] <= 660)
                    {
                        c[i] = 4;
                    }
                    else if (capteurL[i] <= 740)
                    {
                        c[i] = 5;
                    }
                    else if (capteurL[i] <= 820)
                    {
                        c[i] = 6;
                    }
                    else if (capteurL[i] > 820)
                    {
                        c[i] = 7;
                    }
                }

                if (c[0] < c[1])
                {
                        TurnLeft(); //turnleft
                }
                else if (c[0] > c[1])
                {

                        TurnRight(); //turnright

                }
                else
                {
                    Straight();
                }

                //2 capteurs
            }
            if (obstacle == 1)
            {
                if (capteurBlancL <= 650 || capteurBlancR <= 650)
                           {
                               cercle = 1;
                           }
                if(cercle == 1){
                    if (capteurBlancL <= 700 && capteurBlancR > 1000)
                    {
                        Straight();
                        TurnBack();
                        Left();
                        Avance();
                        Avance();
                        //Stop();
                    }
                    else if (capteurBlancR <= 700 && capteurBlancL > 1000)
                    {
                        Straight();
                        TurnBack();
                        Right();
                        Avance();
                        Avance();

                    }
                    else if (capteurBlancL <= 700 && capteurBlancR <= 700)
                    {
                        Straight();
                        Stop();
                        while (1)
                        {
                        }
                    }
                }

            }

        }
        else
        {
            Stop();
            obstacle = 1;
        }

    }

}
