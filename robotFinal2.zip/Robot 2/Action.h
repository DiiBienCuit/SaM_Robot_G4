/*
 * Action.h
 *
 *  Created on: 20 nov. 2017
 *      Author: d.cui.13
 */

void Stop(void);

void Straight(void);

void Avance(void);

void TurnRight(void);

void TurnLeft(void);

void TurnBack(void);

int Compare(unsigned int cap[]);

void CompareAction(int compare);

void Left(void);

void Right(void);
