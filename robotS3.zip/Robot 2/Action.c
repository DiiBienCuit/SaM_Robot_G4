/*
 * Action.c
 *
 *  Created on: 20 nov. 2017
 *      Author: d.cui.13
 */

/*
 * Tous movements de robot
 */
#include <msp430.h>
#include "ADC.h"

void Stop(void){
	TA1CCTL1 = OUTMOD_0;
	TA1CCTL2 = OUTMOD_0;
}

void Straight(void){
	TA1CCTL1 = OUTMOD_7;
	TA1CCTL2 = OUTMOD_7;

	P2OUT |= BIT2;
	P2OUT |= BIT4;

	P2OUT &= ~BIT5; //0
	  P2OUT |= BIT1; //1

}

void TurnRight(void){
	P2OUT &= ~BIT5;
	P2OUT &= ~BIT1;
	__delay_cycles(500000);
	Stop();
}

void TurnLeft(void){
	P2OUT|=BIT1;
	P2OUT|=BIT5;
	TA1CCTL1 = OUTMOD_7;
	TA1CCTL2 = OUTMOD_7;
	__delay_cycles(500000);
	Stop();
}

void Slow(void){
	TA1CCR0 = 500;
	TA1CCR1 = 152;
	TA1CCR2 = 150;
}

void SpeedUp(void){
	TA1CCR0 = 500;
	TA1CCR1 = 403;
	TA1CCR2 = 400;
}

void Back(void){
	P2OUT &= ~BIT1; //0
	P2OUT |= BIT5; //1
	__delay_cycles(500000);
		Stop();
}
