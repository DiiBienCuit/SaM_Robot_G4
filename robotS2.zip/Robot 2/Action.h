/*
 * Action.h
 *
 *  Created on: 20 nov. 2017
 *      Author: d.cui.13
 */
void Stop(void);

void Straight(void);

void TurnRight(void);

void TurnLeft(void);


void Slow(void);

void SpeedUp(void);





