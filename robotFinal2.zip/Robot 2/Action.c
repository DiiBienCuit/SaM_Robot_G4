/*
 * Action.c
 *
 *  Created on: 20 nov. 2017
 *      Author: d.cui.13
 */

/*
 * Tous movements de robot
 */
#include <msp430.h>
#include "ADC.h"

void Stop(void)
{
    TA1CCTL1 = OUTMOD_0;
    TA1CCTL2 = OUTMOD_0;
    __delay_cycles(200000); // delete a la fin
}

void Straight(void)
{
    TA1CCTL1 = OUTMOD_7;
    TA1CCTL2 = OUTMOD_7;
    P2OUT |= (BIT2 | BIT4);
    P2OUT &= ~BIT5; //0
    P2OUT |= BIT1; //1
    __delay_cycles(10000);
}
void Avance(void)
{
    TA1CCTL1 = OUTMOD_7;
    TA1CCTL2 = OUTMOD_7;
    P2OUT |= (BIT2 | BIT4);
    P2OUT &= ~BIT5; //0
    P2OUT |= BIT1; //1
    __delay_cycles(500000);
}

void TurnRight(void)
{
    P2OUT &= ~BIT5;
    P2OUT &= ~BIT1;
    __delay_cycles(10000);

}
void Right(void)
{
    P2OUT &= ~BIT5;
    P2OUT &= ~BIT1;
    TA1CCTL1 = OUTMOD_7;
    TA1CCTL2 = OUTMOD_7;
    TA1CCR1 = 0;
    TA1CCR2 = 250;
    __delay_cycles(400000);


}

void TurnLeft(void)
{
    P2OUT |= BIT1;
    P2OUT |= BIT5;
    TA1CCTL1 = OUTMOD_7;
    TA1CCTL2 = OUTMOD_7;
    __delay_cycles(10000);
}

void Left(void)
{
    P2OUT |= BIT1;
    P2OUT |= BIT5;
    TA1CCR1 = 255;
    TA1CCR2 = 0;
    TA1CCTL1 = OUTMOD_7;
    TA1CCTL2 = OUTMOD_7;
    __delay_cycles(400000);
}

void TurnBack(void)
{
    TA1CCTL1 = OUTMOD_7;
    TA1CCTL2 = OUTMOD_7;
    P2OUT |= (BIT2 | BIT4);
    P2OUT &= ~BIT1; //0
    P2OUT |= BIT5; //1
    __delay_cycles(500000);

}

int Compare(unsigned int cap[])
{
    int i;
    int c[2];
    for (i = 0; i < 2; i++)
    {
        if (cap[i] <= 400)
        {
            c[i] = 0;
        }
        else if (cap[i] <= 500)
        {
            c[i] = 1;
        }
        else if (cap[i] <= 600)
        {
            c[i] = 2;
        }
        else if (cap[i] <= 700)
        {
            c[i] = 3;
        }
        else if (cap[i] <= 800)
        {
            c[i] = 4;
        }
        else if (cap[i] > 800)
        {
            c[i] = 5;
        }
    }

    if (c[0] < c[1])
    {
        return 1; //turnleft
    }
    else if (c[0] > c[1])
    {
        return 2; //turnright
    }
    else
    {
        return 8; //nature
    }
}
void CompareAction(int compare)
{
    switch (compare)
    {
    case 1:
        TurnLeft();
        break;
    case 2:
        TurnRight();
        break;
    case 8:
        Straight();
        break;
    default:
        Straight();
        break;
    }
}
