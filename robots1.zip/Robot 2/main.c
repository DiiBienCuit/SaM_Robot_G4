#include <msp430.h>
#include "ADC.h"
#include "Afficheur.h"
#include "Action.h"

//unsigned char tableau[100];  // d�claration d'un tableau de variables de taille 500

int appui =1;
  int compteur=0;
 unsigned int capteurDevant=0;
 unsigned int capteurDroite=0;
 unsigned int capteurGauche=0;

int main( void )
{
  // Stop watchdog timer to prevent time out reset
	//unsigned int i;
    //unsigned int distance, lumiere;

  WDTCTL = WDTPW + WDTHOLD;


  BCSCTL2 = CALBC1_1MHZ;
  DCOCTL = CALDCO_1MHZ;
  P1DIR &= ~(BIT1); //capteur de lumiere 1

  P2DIR |= (BIT2|BIT1|BIT5|BIT4);
  P2DIR &= ~(BIT0|BIT3);

  P2SEL |= (BIT2|BIT4|BIT0|BIT3);
  P2SEL2 &= ~(BIT2|BIT4|BIT0|BIT3);

  P2OUT |= BIT2;
  P2OUT |= BIT4;

  TA1CTL = 0|(TASSEL_2|ID_0);
  TA1CTL |= MC_1;
  TA1CCTL1 |= OUTMOD_7;
  TA1CCTL2 |= OUTMOD_7;

  TA1CCR0 = 500; // this value to change
  TA1CCR1 = 200;
  TA1CCR2 = 250;

  TACTL = TASSEL_2 + ID_3 + MC_2; //p�riode de 1s

    TA0CCTL0 = CCIE; //interruption au bout de 60s

    TA0CCR0 = 62500; //TAOCCRO pour 1s



  /*ADC_init();
  Aff_Init();*/

  while(1){
//copied
	  ADC_Demarrer_conversion(1); //on d�marre la conversion
	    capteurDevant=ADC_Lire_resultat(); //on lit le r�sultat

	   /* ADC_Demarrer_conversion(6); //on d�marre la conversion
	    capteurDroite=ADC_Lire_resultat(); //on lit le r�sultat

	    ADC_Demarrer_conversion(7); //on d�marre la conversion
	    capteurGauche=ADC_Lire_resultat(); //on lit le r�sultat

	    ADC_Demarrer_conversion(5); //on d�marre la conversion
	    capteurligneGauche=ADC_Lire_resultat(); //on lit le r�sultat

	    ADC_Demarrer_conversion(4); //on d�marre la conversion
	    capteurligneDroite=ADC_Lire_resultat(); //on lit le r�sultat*/
	  if(capteurDevant<500){

		  Straight();
	      		__delay_cycles(400000);
	      		SpeedUp();

	      	}
	      	else{
	      		Stop();
	      		if(capteurDroite<600){
	      			TurnRight();
	      			Stop();
	      		}
	      		else{
	      			TurnLeft();
	      			Stop();
	      		}
	      	}
	 // GetLuminosity(lumiere);
	 /* ADC_Demarrer_conversion(0x01);
	  mesure = ADC_Lire_resultat();
	  lumiere = (mesure -360)/6;
	  if (lumiere<20)

		   Aff_4carac("nuit");
	  else Aff_4carac("jour");

 	  for (i=0; i<40000; i++);*/

  }



}
