/*
 * Action.c
 *
 *  Created on: 20 nov. 2017
 *      Author: d.cui.13
 */

/*
 * Tous movements de robot
 */
#include <msp430.h>
#include "ADC.h"
#include "Afficheur.h"

void Straight(void){
	TA1CCTL1 = OUTMOD_7;
	TA1CCTL2 = OUTMOD_7;

	P2OUT |= BIT2;
		P2OUT |= BIT4;

		P2OUT &= ~BIT1;
		P2OUT |= BIT5;
}

void TurnRight(void){
	P2OUT &= ~BIT5;
		__delay_cycles(500000);
		Stop();
}

void TurnLeft(void){
	P2OUT|=BIT1;
	TA1CCTL1 = OUTMOD_7;
	TA1CCTL2 = OUTMOD_7;
	__delay_cycles(500000);
	Stop();
}

void Stop(void){
	TA1CCTL1 = OUTMOD_0;
	TA1CCTL2 = OUTMOD_0;
}

void Slow(void){
	TA1CCR0 = 500;
	TA1CCR1 = 150;
	TA1CCR2 = 150;
}

void SpeedUp(void){
	TA1CCR0 = 500;
	TA1CCR1 = 400;
	TA1CCR2 = 450;
}

void GetLuminosity(unsigned int lumiere){
	ADC_Demarrer_conversion(0x01);
	unsigned int mesure = ADC_Lire_resultat();
	lumiere = (mesure -360)/6;

	Aff_valeur(lumiere);

}

void GetDistance(){

}

