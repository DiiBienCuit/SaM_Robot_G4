#include <msp430.h> 
#include "ADC.h"
#include "Afficheur.h"

/*
 * main.c
 */

unsigned int i,capteurDevant;

int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer

    P1DIR &= ~BIT0;


    Aff_Init();
    ADC_init();

    while(1){
    	for(i=0;i<50000;i++){

    	}
    	  ADC_Demarrer_conversion(0); //on d�marre la conversion
    	  capteurDevant=ADC_Lire_resultat(); //on lit le r�sultat
    	  Aff_valeur(convert_Hex_Dec(capteurDevant));
    }



	return 0;
}
